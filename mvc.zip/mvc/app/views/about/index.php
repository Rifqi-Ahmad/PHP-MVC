<div class="container mt-3">
    <h1>About Me</h1>
    <img src="<?= BASEURL ?>/img/image.jpeg" alt="Gambar" width="200" height="200" class="rounded-circle shadow">
    <p>Saya <?= $data['nama'] ?>, Saya Seorang <?= $data['pekerjaan'] ?></p>
</div>