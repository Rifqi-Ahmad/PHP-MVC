<div class="container">
    <div class="jumbotron jumbotron-fluid mt-3">
        <div class="container">
            <h1 class="display-4">Welcome</h1>
            <p class="lead">Hallo Saya <?=$data['nama']?></p>
        </div>
    </div>
</div>