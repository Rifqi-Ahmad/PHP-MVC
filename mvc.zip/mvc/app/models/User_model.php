<?php

class User_model{
    private $nama = 'Rifqi';

    public function getUser()
    {
        return $this->nama;
    }
}